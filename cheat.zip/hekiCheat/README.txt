запусти cheathiki
после запусти CHEAT.GENERAL
запусти tank это подключт библеатеку